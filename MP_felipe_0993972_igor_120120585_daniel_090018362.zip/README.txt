1. Para compilar o programa utilize o comando "make".

2. O executável será gerado no diretório raiz, com o nome projetoFinal.

3. Caso queira deletar os arquivos .o, .gcno e .gcda utilize o comando "make clean". 